package com.lib.litron10release.entity.enums;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
