package com.lib.litron10release.DAO;

import com.lib.litron10release.entity.Poem;

public interface PoemDAO extends GeneralDAO<Poem>{
}
