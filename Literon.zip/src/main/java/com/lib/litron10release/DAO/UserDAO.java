package com.lib.litron10release.DAO;

import com.lib.litron10release.entity.UserLiter;

public interface UserDAO extends GeneralDAO<UserLiter>{
}
