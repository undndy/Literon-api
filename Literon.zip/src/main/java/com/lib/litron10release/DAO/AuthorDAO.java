package com.lib.litron10release.DAO;

import com.lib.litron10release.entity.Author;

public interface AuthorDAO extends GeneralDAO<Author> {
}
