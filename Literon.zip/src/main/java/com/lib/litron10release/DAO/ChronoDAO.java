package com.lib.litron10release.DAO;

import com.lib.litron10release.entity.Chronograph;

public interface ChronoDAO extends GeneralDAO<Chronograph>{
}
