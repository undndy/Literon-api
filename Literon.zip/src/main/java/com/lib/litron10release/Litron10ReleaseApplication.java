package com.lib.litron10release;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Litron10ReleaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(Litron10ReleaseApplication.class, args);
    }

}
