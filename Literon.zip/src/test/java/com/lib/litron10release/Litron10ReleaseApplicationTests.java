package com.lib.litron10release;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Litron10ReleaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
